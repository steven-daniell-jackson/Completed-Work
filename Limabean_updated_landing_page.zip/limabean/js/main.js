// Change state of Arrow icon to hover image on mouseenter(Hover) and reverting on mouseleave(Exiting)

jQuery(document).ready(function($) {

// Mouseenter (Hover)
$('.panel').on('mouseenter',  function(e) {
	e.preventDefault();

// Find the icon arrow within the element and changing the image
$(this).find('.icon-arrow').css('background', 'url(img/icon-arrow-hover.png) no-repeat');
});	

// Mouseleave (Exiting)
$('.panel').on('mouseleave',  function(e) {
	e.preventDefault();

// Find the icon arrow within the element and reverting the image
$(this).find('.icon-arrow').css('background', 'url(img/icon-arrow.png) no-repeat');

});	


});
