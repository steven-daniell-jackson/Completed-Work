<?php

// QUESTION 2
// consider the following array

$this_array = array(14,23,264,654,4,34,34);

// write code that will print out the sum of the values in the array
// NOTE: Please do not use the array_sum function


//SUPPLY YOUR ANSWER BELOW THIS COMMENT



// Initialize $total variable
$total = '';

// Loop through Array 
for ($i=0; $i <  sizeof($this_array); $i++) { 

// Add Array value to the running Total variable
	$total = $total + $this_array[$i];

// Visual Elements conditional. Allocate either plus sign on equals sign based on location in the loop.
	if ($i + 1 == sizeof($this_array)) {
		echo $this_array[$i] . " = ";
	}else {
		echo $this_array[$i] . " + ";
	}
} 

// Bolded display of the final total
echo  "<strong>" . $total . "</strong>";