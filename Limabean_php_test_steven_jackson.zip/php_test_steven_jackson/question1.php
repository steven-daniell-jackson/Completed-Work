<?php
/**
  QUESTION 1
  Step 1
  Create a simple HTML table that has 3 rows and 2 columns.
  Step 2
  Into the first column, enter labels for Firstname, Surname and ID Number and in the second column
  put in input fields where a user can enter their Firstname, Surname and ID Number.

  Step 3
  Create a form that will submit this information to the same page

  Step 4
  On the same page, take the submitted information and write a SQL query
  that will insert the posted information into a table called tbl_Person, that has columns
  col_firstname, col_surname, col_idnumber.

  Note: It's optional whether you want to write code that connects to a database and code
  that inserts into the database. We just want to see the SQL query, that uses the posted
  variables to insert into table person
*/
  ?>
  <!-- SUPPLY YOUR ANSWER BELOW THIS COMMENT -->

  <style type="text/css">
  table {margin: 40px;}
  form {margin: 40px; width:400px; border: 1px solid #c3c3c3; text-align:center;}
  form input {margin: 10px 0;}
    .tg  {border-collapse:collapse;border-spacing:0;}
    .tg td{font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal; text-align: center;}
    .tg th{font-family:Arial, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;}
    .tg .tg-yw4l{vertical-align:top;}
  </style>


  <?php 

// Assigning Form data to PHP variables 

// Check if firstname has a value. If not, assigns an empty string
  if (isset( $_GET["firstname"])){
    $firstname = $_GET["firstname"];
  } else {
    $firstname ="";
  }

// Check if surname has a value. If not, assigns an empty string
  if (isset( $_GET["surname"])){
    $surname = $_GET["surname"];
  } else {
    $surname ="";
  }

// Check if ID has a value. If not, assigns an empty string
  if (isset( $_GET["id"])){

    $id = (int)$_GET["id"];
    // If value cannot be parsed to INT. Display error message
    if ($id === 0) {
      $id = "<span style=\"color:red;\">You have entered an incorrect ID Number. <br> Please make sure that it is a numeric value";
    };

  } else {
    $id ="";
  }

  ?>

  <!-- Step 1, 2 and Question 3 - Data display -->
  <table class="tg">
    <tr>
      <th class="tg-yw4l">Firstname</th>
      <th class="tg-yw4l"> <?php echo $firstname; ?></th>
    </tr>
    <tr>
      <td class="tg-yw4l">Surname</td>
      <td class="tg-yw4l"> <?php echo $surname; ?></td>
    </tr>
    <tr>
      <td class="tg-yw4l">ID Number</td>
      <td class="tg-yw4l"> <?php echo $id; ?></td>
    </tr>
  </table>


  <!-- Step 3 -->
  <form action="question1.php" method="GET">
    First name:<br>
    <input type="text" name="firstname" required><br>
    Surname:<br>
    <input type="text" name="surname" required><br>
    ID Number:<br>
    <input type="text" name="id" required><br>
    <button>Submit</button><br><br>
  </form>


<!-- Step 4 -->

<!-- Assumed Table structure -->
CREATE TABLE tbl_Person (
col_firstname varchar(25),
col_surname varchar(25),
col_idnumber int
);

<!-- Step 4 Answer -->
INSERT INTO tbl_Person VALUES ('<?php echo $firstname; ?>','<?php echo $surname; ?>','<?php echo $id; ?>')

