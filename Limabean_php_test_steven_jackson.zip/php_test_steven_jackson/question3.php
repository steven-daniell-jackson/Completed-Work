<?php

// QUESTION 3

// consider the following array

$person_array = array('Leanna', 'derek', 'Lisa', 'John', 'lancelot', 'Michael', 'norman', 'Lawrence of Arabia');

/**
  write a loop that will print out (on a new line) all names that
  begin with L or l (both uppercase and lowercase) that are longer than 5 characters
 */

//SUPPLY YOUR ANSWER BELOW THIS COMMENT


// Loop through Array
  for ($i=0; $i <  sizeof($person_array); $i++) {

/*
Capatilize the first letter of the name and select the first Character and allocate to $person variable for comparison
Eg. "derek" becomes "Derek" and then select the first Character. Which would be "D" in this instance

Gets the Length of the string and assigns to the $personLength variable
*/

$person = substr(ucfirst($person_array[$i]),0,1);
$personLength = strlen($person_array[$i]);


// If $person contains an L and has a character length greater than 5. Display the name with the first Letter capatilized
if ($person == "L" && $personLength > 5 ) {
	echo ucfirst($person_array[$i]) . "<br>";

}

}