<?php

// QUESTION 4
// consider the following array
$person_array = array('Leanna', 'derek', 'Lisa', 'John', 'Lancelot', 'Michael', 'Norman', 'Lawrence of Arabia');

// Create an output array that contains all distinct characters (Uppercase and Lowercase)
// from the strings contained within the array above. Use only the str_split function 
// and any of the Array functions to do so.

//SUPPLY YOUR ANSWER BELOW THIS COMMENT


/****************************************************************

Did not really understand what was required here.
However, I split the names into individual arrays.

Please view the page source for a more structured view

****************************************************************/


// Loop through Array
for ($i=0; $i <  sizeof($person_array); $i++) { 

// Split each name into a new array with each character becoming it's own element
$array = str_split($person_array[$i], 1);
// Print Array
print_r($array);

  }